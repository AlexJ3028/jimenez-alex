import { getPokemon, renderPokemon, sanitizedName } from './modulos/api.js';

const htmlElements = {
    form: document.querySelector('#pokemon-form'),
    pokemonDetails: document.querySelector('#pokemon-details')
};


const handlers = {
    submit: async (event) => {
        event.preventDefault();

        const formData = new FormData(event.target);
        const pokemonName = formData.get('pokemon-name');
        const safeName = sanitizedName(pokemonName);

        if (!safeName) {
            alert('¡OYE! Coloca un Pokémon que exista, ¡debes culturizarte!');
            return;
        }

        try {
            const pokemon = await getPokemon(safeName);
            htmlElements.pokemonDetails.innerHTML = ''; // Limpiar la sección antes de agregar el nuevo Pokémon
            renderPokemon(htmlElements.pokemonDetails, pokemon);
        } catch (error) {
            alert('Pokémon no encontrado, CULTURIZATE!.');
        }
    }
};

const bindEvents = () => {
    htmlElements.form.addEventListener('submit', handlers.submit);
};

const init = () => {
    bindEvents();
};

init();





