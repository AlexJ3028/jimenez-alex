export class Aby {
    constructor(name, learners) {
        this.name = name;
        this.learners = learners;
    }

    // Capitalizar el primer carácter del nombre de la habilidad
    getCapitalizedName() {
        return this.name[0].toUpperCase() + this.name.slice(1);
    }

    // Generar representación HTML para la habilidad
    toHTML() {
        const learnersList = this.learners.map(
            (learner) => `
                <li>
                    ${learner.name}
                    ${learner.isHidden ? '<span class="hidden-ability">👁️</span>' : ''}
                </li>
            `
        ).join(''); // Convertir los aprendices en un listado HTML

        return `
            <div class="ability-details">
                <h3 class="ability-heading">${this.getCapitalizedName()}</h3>
                <div class="ability-body">
                    <p class="ability-learners-title"><strong>Who can learn it?</strong></p>
                    <ul class="ability-learners-list">${learnersList}</ul>
                </div>
            </div>
        `;
    }
}
