import { PokemonService } from './pokeservice.js';
import { Pokemon } from './pokemon.js';
import { Ability } from './aby.js';
import { htmlElements, uiHandlers } from './ui.js';

// Definir funciones que gestionan las acciones del usuario
const eventHandlers = {
  // Buscar Pokémon o habilidad en función de la entrada del usuario
  onSearch: async (e) => {
    e.preventDefault(); // Prevenir el comportamiento predeterminado del formulario
    const typeOfSearch = htmlElements.searchTypeSelect.value; // Obtener tipo de búsqueda seleccionado
    const query = htmlElements.searchInput.value.trim(); // Obtener término de búsqueda
    if (!query) return; // Si el término de búsqueda está vacío, no hacer nada

    try {
      if (typeOfSearch === 'pokemon') {
        // Obtener datos del Pokémon si el tipo de búsqueda es 'pokemon'
        const data = await Pokeservice.fetchPokemonData(query);
        const pokemonInstance = new Pokemon(
          data.name,
          data.id,
          data.sprites.front_default,
          data.sprites.back_default,
          data.weight,
          data.height,
          data.evolutionChain,
          data.abilities
        );
        uiHandlers.displayPokemon(pokemonInstance); // Mostrar el Pokémon en la interfaz de usuario
      } else if (typeOfSearch === 'ability') {
        // Obtener datos de la habilidad si el tipo de búsqueda es 'ability'
        const abilityData = await Pokeservice.fetchAbilityData(query);
        const abilityInstance = new Ability(abilityData.name, abilityData.learners);
        uiHandlers.displayAbility(abilityInstance); // Mostrar la habilidad en la interfaz de usuario
      }
    } catch (err) {
      // Manejar errores específicos según el mensaje del error
      if (err.message === 'Pokémon no encontrado') {
        uiHandlers.displayError('pokemon'); // Error específico para Pokémon no encontrado
      } else if (err.message === 'Habilidad no encontrada') {
        uiHandlers.displayError('ability'); // Error específico para habilidad no encontrada
      } else {
        uiHandlers.displayError(); // Error general
      }
    }
  }
};

// Vincular eventos a los elementos HTML
const attachEvents = () => {
  htmlElements.searchButton.addEventListener('click', eventHandlers.onSearch); // Asignar evento de clic para buscar
  htmlElements.clearButton.addEventListener('click', uiHandlers.clearSearch); // Asignar evento de clic para limpiar búsqueda
  htmlElements.searchTypeSelect.addEventListener('change', uiHandlers.handleSearchTypeChange); // Cambiar tipo de búsqueda
};

// Inicializar la aplicación
const initialize = () => {
  attachEvents(); // Llamar a la función para adjuntar eventos
};

initialize(); // Ejecutar inicialización
