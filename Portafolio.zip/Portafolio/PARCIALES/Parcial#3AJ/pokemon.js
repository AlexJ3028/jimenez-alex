export class Pokemon {
    constructor(name, id, frontSprite, backSprite, weight, height, evolutionChain, abilities) {
        this.name = name;
        this.id = id;
        this.frontSprite = frontSprite;
        this.backSprite = backSprite;
        this.weight = weight;
        this.height = height;
        this.evolutionChain = evolutionChain;
        this.abilities = abilities;
    }

    // Devuelve el nombre con la primera letra en mayúscula
    getCapitalizedName() {
        return this.name[0].toUpperCase() + this.name.slice(1);
    }

    // Generar representación HTML de los datos del Pokémon
    toHTML() {
        const evolutionHTML = this.evolutionChain.map(
            (evo) => `
                <li>
                    ${this.capitalize(evo.name)}
                    ${evo.isBaby ? '👶' : ''}
                </li>
            `
        ).join(''); // Crear HTML para la cadena de evolución

        const abilitiesHTML = this.abilities.map(
            (ability) => `
                <li>
                    ${this.capitalize(ability.name)}
                    ${ability.isHidden ? '👁️' : ''}
                </li>
            `
        ).join(''); // Crear HTML para la lista de habilidades

        return `
            <h3 class="pokemon-header">${this.getCapitalizedName()} (#${this.id})</h3>
            <div class="pokemon-details">
                <div class="info-section">
                    <div class="sprite-container">
                        <p><strong>Sprites:</strong></p>
                        <div class="sprites">
                            <img src="${this.frontSprite}" alt="${this.name} front view">
                            <img src="${this.backSprite}" alt="${this.name} back view">
                        </div>
                    </div>
                    <div class="size-info">
                        <p><strong>Weight / Height:</strong></p>
                        <p>${this.weight} kg / ${this.height} m</p>
                    </div>
                </div>
                <div class="info-section">
                    <div class="evolution-info">
                        <p><strong>Evolution Chain:</strong></p>
                        <ul class="evolution-chain">${evolutionHTML}</ul>
                    </div>
                    <div class="abilities-info">
                        <p><strong>Abilities:</strong></p>
                        <ul class="ability-list">${abilitiesHTML}</ul>
                    </div>
                </div>
            </div>
        `;
    }

    // Capitalizar la primera letra de una palabra
    capitalize(word) {
        return word[0].toUpperCase() + word.slice(1);
    }
}
