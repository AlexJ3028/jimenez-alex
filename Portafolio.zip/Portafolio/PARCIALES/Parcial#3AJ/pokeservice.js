export class Pokeservice {
    // Método estático para obtener datos de un Pokémon específico
    static async getPokemonData(pokemonName) {
        try {
            // Realizar la solicitud para obtener información del Pokémon
            const pokemonResponse = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName.toLowerCase()}`);
            if (!pokemonResponse.ok) throw new Error('Pokémon no encontrado');
            const basicData = await pokemonResponse.json();

            // Obtener información de la especie para acceder a la cadena evolutiva
            const speciesResponse = await fetch(basicData.species.url);
            const speciesInfo = await speciesResponse.json();

            // Obtener la cadena evolutiva desde la URL de la especie
            const chainResponse = await fetch(speciesInfo.evolution_chain.url);
            const chainData = await chainResponse.json();

            // Procesar y construir la cadena evolutiva
            const chain = [];
            let evolutionNode = chainData.chain;

            while (evolutionNode) {
                chain.push({
                    name: evolutionNode.species.name,
                    isBaby: evolutionNode.is_baby
                });
                evolutionNode = evolutionNode.evolves_to[0]; // Solo tomamos la primera evolución para simplicidad
            }

            // Retornar datos del Pokémon con la cadena evolutiva procesada
            return {
                ...basicData,
                evolutionChain: chain,
                abilities: basicData.abilities.map((abilityInfo) => ({
                    name: abilityInfo.ability.name,
                    isHidden: abilityInfo.is_hidden
                }))
            };
        } catch (err) {
            console.error('Error al recuperar datos del Pokémon:', err);
            throw err;
        }
    }

    // Método estático para obtener datos de una habilidad específica
    static async getAbilityData(abilityName) {
        try {
            const abilityResponse = await fetch(`https://pokeapi.co/api/v2/ability/${abilityName.toLowerCase()}`);
            if (!abilityResponse.ok) throw new Error('Habilidad no encontrada');
            const abilityInfo = await abilityResponse.json();

            // Transformar los datos para mostrar los Pokémon que aprenden esta habilidad
            return {
                name: abilityInfo.name,
                learners: abilityInfo.pokemon.map((pokeInfo) => ({
                    name: pokeInfo.pokemon.name,
                    isHidden: pokeInfo.is_hidden
                }))
            };
        } catch (err) {
            console.error('Error al recuperar datos de la habilidad:', err);
            throw err;
        }
    }
}
