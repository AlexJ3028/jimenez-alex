// Elementos HTML comunes que se utilizarán en la interfaz de usuario
export const htmlElements = {
    searchButton: document.getElementById('search-button'),
    clearButton: document.getElementById('clear-button'),
    buttonWrapper: document.querySelector('.button-container'),
    pokemonDetails: document.getElementById('pokemon-info'),
    abilityDetails: document.querySelector('.ability-info'),
    searchTypeDropdown: document.getElementById('search-type'),
    searchInputField: document.getElementById('pokemon-name')
};

// Funciones de interfaz de usuario para manejar la visualización de datos y mensajes
export const uiHandlers = {
    showPokemon(pokemon) {
        htmlElements.pokemonDetails.innerHTML = pokemon.toHTML();
        htmlElements.pokemonDetails.style.display = 'block';
        htmlElements.abilityDetails.style.display = 'none';
        htmlElements.clearButton.style.display = 'inline';
        htmlElements.buttonWrapper.classList.add('space-between');
    },

    showAbility(ability) {
        htmlElements.abilityDetails.innerHTML = ability.toHTML();
        htmlElements.abilityDetails.style.display = 'block';
        htmlElements.pokemonDetails.style.display = 'none';
        htmlElements.clearButton.style.display = 'inline';
        htmlElements.buttonWrapper.classList.add('space-between');
    },

    showError(errorType) {
        if (errorType === 'pokemon') {
            htmlElements.pokemonDetails.innerHTML = '<p>Pokémon no encontrado.</p>';
        } else if (errorType === 'ability') {
            htmlElements.pokemonDetails.innerHTML = '<p>Habilidad no encontrada.</p>';
        } else {
            htmlElements.pokemonDetails.innerHTML = '<p>Error desconocido.</p>';
        }
        htmlElements.pokemonDetails.style.display = 'block';
        htmlElements.abilityDetails.style.display = 'none';
    },

    clearResults() {
        htmlElements.searchInputField.value = '';
        htmlElements.pokemonDetails.innerHTML = '';
        htmlElements.abilityDetails.innerHTML = '';
        htmlElements.pokemonDetails.style.display = 'none';
        htmlElements.abilityDetails.style.display = 'none';
        htmlElements.clearButton.style.display = 'none';
        htmlElements.buttonWrapper.classList.remove('space-between');
    },

    updateSearchType() {
        const selectedType = htmlElements.searchTypeDropdown.value;
        htmlElements.pokemonDetails.style.display = 'none';
        htmlElements.abilityDetails.style.display = 'none';
    }
};
