const API = (() => {
    const BASE_URL = 'https://www.thecocktaildb.com/api/json/v1/1';
    const API_URLS = {
        // Search endpoints
        searchByName: (name) => `${BASE_URL}/search.php?s=${name}`,
        searchByLetter: (letter) => `${BASE_URL}/search.php?f=${letter}`,
        searchIngredient: (name) => `${BASE_URL}/search.php?i=${name}`,
        
        // Lookup endpoints
        lookupCocktailById: (id) => `${BASE_URL}/lookup.php?i=${id}`,
        lookupIngredientById: (id) => `${BASE_URL}/lookup.php?iid=${id}`,
        getRandomCocktail: () => `${BASE_URL}/random.php`,
        
        // Filter endpoints
        filterByIngredient: (ingredient) => `${BASE_URL}/filter.php?i=${ingredient}`,
        filterByAlcoholic: (type) => `${BASE_URL}/filter.php?a=${type}`,
        filterByCategory: (category) => `${BASE_URL}/filter.php?c=${category}`,
        filterByGlass: (glass) => `${BASE_URL}/filter.php?g=${glass}`,
        
        // List endpoints
        getCategories: () => `${BASE_URL}/list.php?c=list`,
        getGlasses: () => `${BASE_URL}/list.php?g=list`,
        getIngredients: () => `${BASE_URL}/list.php?i=list`,
        getAlcoholicTypes: () => `${BASE_URL}/list.php?a=list`,
        
        // Image URLs
        getDrinkThumb: (filename) => `${BASE_URL}/images/media/drink/${filename}`,
        getDrinkThumbPreview: (filename) => `${BASE_URL}/images/media/drink/${filename}/preview`,
        getIngredientImage: (name, size = 'Medium') => 
            `https://www.thecocktaildb.com/images/ingredients/${name}-${size}.png`
    };

    const fetchData = async (url) => {
        try {
            const response = await fetch(url);
            return response.json();
        } catch (error) {
            console.error("Error fetching data:", error);
            return null;
        }
    };

    return {
        // Search methods
        searchCocktails: async (query) => await fetchData(API_URLS.searchByName(query)),
        searchByLetter: async (letter) => await fetchData(API_URLS.searchByLetter(letter)),
        searchIngredients: async (query) => await fetchData(API_URLS.searchIngredient(query)),
        
        // Lookup methods
        getCocktailById: async (id) => await fetchData(API_URLS.lookupCocktailById(id)),
        getIngredientById: async (id) => await fetchData(API_URLS.lookupIngredientById(id)),
        getRandomCocktail: async () => await fetchData(API_URLS.getRandomCocktail()),
        
        // Filter methods
        filterByIngredient: async (ingredient) => await fetchData(API_URLS.filterByIngredient(ingredient)),
        filterByAlcoholic: async (type) => await fetchData(API_URLS.filterByAlcoholic(type)),
        filterByCategory: async (category) => await fetchData(API_URLS.filterByCategory(category)),
        filterByGlass: async (glass) => await fetchData(API_URLS.filterByGlass(glass)),
        
        // List methods
        getCategories: async () => await fetchData(API_URLS.getCategories()),
        getGlasses: async () => await fetchData(API_URLS.getGlasses()),
        getIngredients: async () => await fetchData(API_URLS.getIngredients()),
        getAlcoholicTypes: async () => await fetchData(API_URLS.getAlcoholicTypes()),
        
        // Image URLs
        getDrinkThumbUrl: (filename) => API_URLS.getDrinkThumb(filename),
        getDrinkThumbPreviewUrl: (filename) => API_URLS.getDrinkThumbPreview(filename),
        getIngredientImageUrl: (name, size) => API_URLS.getIngredientImage(name, size)
    };
})();

// uiModule.js
const UI = (() => {
    const elements = {
        searchInput: document.getElementById('searchInput'),
        resultsContainer: document.getElementById('resultsContainer'),
        searchCocktailsBtn: document.getElementById('searchCocktailsBtn'),
        searchIngredientsBtn: document.getElementById('searchIngredientsBtn')
    };

    const updateSearchType = (type) => {
        elements.searchCocktailsBtn.classList.toggle('active', type === 'cocktails');
        elements.searchIngredientsBtn.classList.toggle('active', type === 'ingredients');
        elements.searchInput.placeholder = `Search for ${type}...`;
    };

    const createCocktailCard = (cocktail) => {
        // Fix the image URL by removing any "/preview" suffix
        const imageUrl = cocktail.strDrinkThumb?.replace('/preview', '') || 'placeholder.png';
        
        return `
            <div class="cocktail-card">
                <div class="cocktail-image-container">
                    <img 
                        src="${imageUrl}" 
                        alt="${cocktail.strDrink}"
                        class="cocktail-image"
                        onerror="this.src='placeholder.png'"
                    >
                </div>
                <div class="cocktail-info">
                    <h3>${cocktail.strDrink}</h3>
                    <p>${cocktail.strInstructions?.slice(0, 150) || 'No instructions available'}...</p>
                    <div class="cocktail-tags">
                        ${cocktail.strCategory ? `<span class="tag">${cocktail.strCategory}</span>` : ''}
                        ${cocktail.strAlcoholic ? `<span class="tag">${cocktail.strAlcoholic}</span>` : ''}
                        ${cocktail.strGlass ? `<span class="tag">${cocktail.strGlass}</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    };

    const createIngredientCard = (ingredient) => `
        <div class="cocktail-card">
            <img src="${API.getIngredientImageUrl(ingredient.strIngredient, 'Medium')}" alt="${ingredient.strIngredient}" class="cocktail-image">
            <div class="cocktail-info">
                <h3>${ingredient.strIngredient}</h3>
                <p>${ingredient.strDescription?.slice(0, 150) || 'No description available'}...</p>
            </div>
        </div>
    `;

    const displayResults = (data = [], type = 'cocktails') => {
        if (!data.length) {
            elements.resultsContainer.innerHTML = `
                <div class="no-results">
                    <h2>No results found</h2>
                    <p>Try a different search term</p>
                </div>`;
            return;
        }

        elements.resultsContainer.innerHTML = `
            <div class="results-grid">
                ${data.map(item => type === 'cocktails' ? createCocktailCard(item) : createIngredientCard(item)).join('')}
            </div>`;
    };

    const loadFilters = async () => {
        const [categories, types, glasses] = await Promise.all([
            API.getCategories(),
            API.getAlcoholicTypes(),
            API.getGlasses()
        ]);

        document.getElementById('typeFilters').innerHTML = types.drinks
            .map(type => `<button class="filter-btn" data-type="alcoholic" data-value="${type.strAlcoholic}">
                ${type.strAlcoholic}</button>`).join('');

        document.getElementById('categoryFilters').innerHTML = categories.drinks
            .map(cat => `<button class="filter-btn" data-type="category" data-value="${cat.strCategory}">
                ${cat.strCategory}</button>`).join('');

        document.getElementById('glassFilters').innerHTML = glasses.drinks
            .map(glass => `<button class="filter-btn" data-type="glass" data-value="${glass.strGlass}">
                ${glass.strGlass}</button>`).join('');

        // Add event listeners to filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const type = btn.dataset.type;
                const value = btn.dataset.value;
                const response = await API[`filterBy${type.charAt(0).toUpperCase() + type.slice(1)}`](value);
                if (response?.drinks) {
                    displayResults(response.drinks, 'cocktails');
                }
            });
        });
    };

    const performSearch = async (query, type) => {
        const response = await API[type === 'cocktails' ? 'searchCocktails' : 'searchIngredients'](query);
        const data = response?.[type === 'cocktails' ? 'drinks' : 'ingredients'] || [];
        displayResults(data, type);
    };

    return {
        getInputValue: () => elements.searchInput.value.trim(),
        updateSearchType,
        displayResults,
        loadFilters,
        performSearch,
        displayCocktail: (cocktail) => displayResults([cocktail], 'cocktails')
    };
})();

// main.js
const Main = (() => {
    let activeSearchType = 'cocktails';
    const sections = ['exploreSection', 'apiSection', 'resultsContainer'];

    const showSection = (sectionId) => {
        sections.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.style.display = id === sectionId ? 'block' : 'none';
            }
        });
    };

    const setupEventListeners = () => {
        // Search Type Buttons
        document.getElementById('searchCocktailsBtn')?.addEventListener('click', () => {
            activeSearchType = 'cocktails';
            UI.updateSearchType('cocktails');
        });

        document.getElementById('searchIngredientsBtn')?.addEventListener('click', () => {
            activeSearchType = 'ingredients';
            UI.updateSearchType('ingredients');
        });

        // Search Button
        document.getElementById('searchBtn')?.addEventListener('click', handleSearch);
        document.getElementById('searchInput')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleSearch();
        });

        // Random Cocktail Button
        document.getElementById('getRandomCocktailBtn')?.addEventListener('click', loadRandomCocktail);
    };

    const handleSearch = async () => {
        const query = UI.getInputValue();
        if (!query) return;

        showSection('resultsContainer');
        await UI.performSearch(query, activeSearchType);
    };

    const loadRandomCocktail = async () => {
        const response = await API.getRandomCocktail();
        if (response?.drinks?.[0]) {
            const randomCocktailContainer = document.getElementById('randomCocktailContainer');
            if (randomCocktailContainer) {
                randomCocktailContainer.innerHTML = UI.createCocktailCard(response.drinks[0]);
            }
        }
    };

    const init = () => {
        setupEventListeners();
        if (window.location.pathname.includes('explore.html')) {
            UI.loadFilters();
        } else if (window.location.pathname.includes('random.html')) {
            loadRandomCocktail();
        }
    };

    return { init };
})();

// Initialize App
document.addEventListener('DOMContentLoaded', Main.init);

