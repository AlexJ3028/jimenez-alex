document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const resultsContainer = document.getElementById('resultsContainer');
    const featuredCocktailSection = document.getElementById('featuredCocktailSection');
    const cocktailImage = document.getElementById('cocktailImage');
    const cocktailName = document.getElementById('cocktailName');
    const cocktailDescription = document.getElementById('cocktailDescription');
    const randomCocktailContainer = document.getElementById('randomCocktailContainer'); // Asegúrate de que este contenedor exista

    // Fetch a random cocktail on page load
    async function fetchRandomCocktail() {
        const response = await fetch('https://www.thecocktaildb.com/api/json/v1/1/random.php');
        const data = await response.json();
        const cocktail = data.drinks[0];

        // Update the Featured Cocktail section
        cocktailName.textContent = cocktail.strDrink;
        cocktailDescription.textContent = cocktail.strInstructions;
        cocktailImage.src = cocktail.strDrinkThumb;

        // Also update the random cocktail section (if needed)
        if (randomCocktailContainer) {
            randomCocktailContainer.innerHTML = `
                <img src="${cocktail.strDrinkThumb}" alt="${cocktail.strDrink}" class="cocktail-image">
                <div class="cocktail-info">
                    <h3>${cocktail.strDrink}</h3>
                    <p>${cocktail.strInstructions}</p>
                </div>
            `;
        }
    }

    // Call the function to load a random cocktail when the page loads
    fetchRandomCocktail();

    // Function to hide the featured cocktail section when searching
    function hideFeaturedCocktail() {
        featuredCocktailSection.classList.add('hidden');
    }

    // Function to show the featured cocktail again if no search query
    function showFeaturedCocktail() {
        featuredCocktailSection.classList.remove('hidden');
    }

    // Perform search
    async function searchCocktail() {
        const query = searchInput.value.trim();

        if (query) {
            // Hide the featured cocktail section when performing search
            hideFeaturedCocktail();

            // Fetch cocktails based on search query
            const response = await fetch(`https://www.thecocktaildb.com/api/json/v1/1/search.php?s=${query}`);
            const data = await response.json();

            if (data.drinks) {
                resultsContainer.innerHTML = data.drinks.map(cocktail => `
                    <div class="cocktail-card">
                        <img src="${cocktail.strDrinkThumb}" alt="${cocktail.strDrink}" class="cocktail-image">
                        <div class="cocktail-info">
                            <h3>${cocktail.strDrink}</h3>
                            <p>${cocktail.strInstructions.slice(0, 150)}...</p>
                        </div>
                    </div>
                `).join('');
            } else {
                resultsContainer.innerHTML = '<p>No cocktails found. Try again.</p>';
            }
        } else {
            // If the search input is empty, show featured cocktail section again
            showFeaturedCocktail();
        }
    }

    // Listen for the search button click
    searchBtn.addEventListener('click', searchCocktail);

    // Event for getting another random cocktail
    document.getElementById('getRandomCocktailBtn')?.addEventListener('click', fetchRandomCocktail);
});
