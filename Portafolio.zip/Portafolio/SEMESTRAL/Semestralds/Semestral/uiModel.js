import API from './apiModule.js';

const UI = (() => {
    const elements = {
        searchInput: document.getElementById('searchInput'),
        resultsContainer: document.getElementById('resultsContainer'),
        searchCocktailsBtn: document.getElementById('searchCocktailsBtn'),
        searchIngredientsBtn: document.getElementById('searchIngredientsBtn')
    };

    const updateSearchType = (type) => {
        elements.searchCocktailsBtn.classList.toggle('active', type === 'cocktails');
        elements.searchIngredientsBtn.classList.toggle('active', type === 'ingredients');
        elements.searchInput.placeholder = `Search for ${type}...`;
    };

    const createCocktailCard = (cocktail) => `
        <div class="cocktail-card">
            <img src="${cocktail.strDrinkThumb}" alt="${cocktail.strDrink}" class="cocktail-image">
            <div class="cocktail-info">
                <h3>${cocktail.strDrink}</h3>
                <p>${cocktail.strInstructions?.slice(0, 150)}...</p>
                <div class="cocktail-tags">
                    ${cocktail.strCategory ? `<span class="tag">${cocktail.strCategory}</span>` : ''}
                    ${cocktail.strAlcoholic ? `<span class="tag">${cocktail.strAlcoholic}</span>` : ''}
                    ${cocktail.strGlass ? `<span class="tag">${cocktail.strGlass}</span>` : ''}
                </div>
            </div>
        </div>
    `;

    const displayResults = (data = [], type = 'cocktails') => {
        if (!data.length) {
            elements.resultsContainer.innerHTML = `
                <div class="no-results">
                    <h2>No results found</h2>
                    <p>Try a different search term</p>
                </div>`;
            return;
        }

        elements.resultsContainer.innerHTML = `
            <div class="results-grid">
                ${data.map(item => type === 'cocktails' ? createCocktailCard(item) : createIngredientCard(item)).join('')}
            </div>`;
    };

    const loadFilters = async () => {
        const [categories, types, glasses] = await Promise.all([
            API.getCategories(),
            API.getAlcoholicTypes(),
            API.getGlasses()
        ]);
   
        console.log(categories, types, glasses); // Agrega esto para verificar las respuestas
   
        document.getElementById('typeFilters').innerHTML = types.drinks
            .map(type => `<button class="filter-btn" data-type="alcoholic" data-value="${type.strAlcoholic}">
                ${type.strAlcoholic}</button>`).join('');
   
        document.getElementById('categoryFilters').innerHTML = categories.drinks
            .map(cat => `<button class="filter-btn" data-type="category" data-value="${cat.strCategory}">
                ${cat.strCategory}</button>`).join('');
   
        document.getElementById('glassFilters').innerHTML = glasses.drinks
            .map(glass => `<button class="filter-btn" data-type="glass" data-value="${glass.strGlass}">
                ${glass.strGlass}</button>`).join('');
   
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const type = btn.dataset.type;
                const value = btn.dataset.value;
                const response = await API[`filterBy${type.charAt(0).toUpperCase() + type.slice(1)}`](value);
                if (response?.drinks) {
                    displayResults(response.drinks, 'cocktails');
                }
            });
        });
    };
   

    const performSearch = async (query, type) => {
        const response = await API[type === 'cocktails' ? 'searchCocktails' : 'searchIngredients'](query);
        const data = response?.[type === 'cocktails' ? 'drinks' : 'ingredients'] || [];
        displayResults(data, type);
    };

    return {
        getInputValue: () => elements.searchInput.value.trim(),
        updateSearchType,
        displayResults,
        loadFilters,
        performSearch,
        displayCocktail: (cocktail) => displayResults([cocktail], 'cocktails')
    };
})();

export default UI;
