document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const resultsContainer = document.getElementById('resultsContainer');
    const featuredCocktailSection = document.getElementById('featuredCocktailSection');
    const cocktailImage = document.getElementById('cocktailImage');
    const cocktailName = document.getElementById('cocktailName');
    const cocktailDescription = document.getElementById('cocktailDescription');

    // Fetch a random cocktail on page load
    async function fetchRandomCocktail() {
        const response = await fetch('https://www.thecocktaildb.com/api/json/v1/1/random.php');
        const data = await response.json();
        const cocktail = data.drinks[0];

        // Update the Featured Cocktail section
        document.getElementById('cocktailName').textContent = cocktail.strDrink;
        document.getElementById('cocktailDescription').textContent = cocktail.strInstructions;
        document.getElementById('cocktailImage').src = cocktail.strDrinkThumb;
    }

    // Call the function to load a random cocktail when the page loads
    fetchRandomCocktail();

    // Function to hide the featured cocktail section when searching
    function hideFeaturedCocktail() {
        featuredCocktailSection.classList.add('hidden');
    }

    // Function to show the featured cocktail again if no search query
    function showFeaturedCocktail() {
        featuredCocktailSection.classList.remove('hidden');
    }

    // Perform search
    async function searchCocktail() {
        const query = searchInput.value.trim();

        if (query) {
            // Hide the featured cocktail section when performing search
            hideFeaturedCocktail();

            // Fetch cocktails based on search query
            const response = await fetch(`https://www.thecocktaildb.com/api/json/v1/1/search.php?s=${query}`);
            const data = await response.json();

            if (data.drinks) {
                resultsContainer.innerHTML = data.drinks.map(cocktail => `
                    <div class="cocktail-card">
                        <img src="${cocktail.strDrinkThumb}" alt="${cocktail.strDrink}" class="cocktail-image">
                        <div class="cocktail-info">
                            <h3>${cocktail.strDrink}</h3>
                            <p>${cocktail.strInstructions.slice(0, 150)}...</p>
                        </div>
                    </div>
                `).join('');
            } else {
                resultsContainer.innerHTML = '<p>No cocktails found. Try again.</p>';
            }
        } else {
            // If the search input is empty, show featured cocktail section again
            showFeaturedCocktail();
        }
    }
    document.addEventListener("DOMContentLoaded", function() {
        // Función para obtener un cóctel aleatorio de la API
        async function fetchRandomCocktail() {
            // Llamada a la API para obtener un cóctel aleatorio
            const response = await fetch('https://www.thecocktaildb.com/api/json/v1/1/random.php');
            const data = await response.json();
            const cocktail = data.drinks[0];
    
            // Actualizamos el contenido del contenedor con la información del cóctel aleatorio
            const cocktailCard = document.getElementById('randomCocktailContainer');
            cocktailCard.innerHTML = `
                <img src="${cocktail.strDrinkThumb}" alt="${cocktail.strDrink}" class="cocktail-image">
                <div class="cocktail-info">
                    <h3>${cocktail.strDrink}</h3>
                    <p>${cocktail.strInstructions}</p>
                </div>
            `;
        }
    
        // Llamamos a la función para cargar un cóctel aleatorio cuando se carga la página
        fetchRandomCocktail();
    
        // Evento para el botón de "Get Another Random Cocktail"
        document.getElementById('getRandomCocktailBtn').addEventListener('click', fetchRandomCocktail);
    });
    
    // Listen for the search button click
    searchBtn.addEventListener('click', searchCocktail);
});
